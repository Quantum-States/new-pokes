
public class NatureObject extends PokemonObject {
	/*
	 * hardy = neutral
	 * lonely = attack up, defense down
	 * adamant = attack up, special attack down
	 * naughty = attack up, sp def down
	 * brave = atk up, speed down
	 * 
	 * bold = defense up, atk down
	 * docile = neutral
	 * impish = defense up, sp atk down
	 * lax = defense up, sp def down
	 * relaxed = defense up, speed down
	 * 
	 * modest = sp. atk up, atk down
	 * mild = sp. atk up, def down
	 * bashful = neutral
	 * rash = sp. atk up, sp def down
	 * quiet = sp. atk up, speed down
	 * 
	 * calm = sp. def up, atk down
	 * gentle = sp. def up, def down
	 * careful = sp. def up, sp atk down
	 * quirky = neutral
	 * sassy = sp. def up, speed down
	 * 
	 * timid = speed, atk down
	 * hasty = speed, def down
	 * jolly = speed, sp atk down
	 * naive = speed, sp def down
	 * serious = neutral
	 */

}
