
public class Moves {
//a WHOLE bunch of methods. each method contains how stats effect it
}
