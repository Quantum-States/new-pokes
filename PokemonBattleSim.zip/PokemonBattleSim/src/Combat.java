
public class Combat {
//this is where evs are "transferred" from one pokemon to the next
}
